File extension key:

.cmp	component side (top) copper
.sol 	solder side (bottom) copper
.plc	component side (top) silkscreen
.pls	solder side (bottom) silkscreen
.stc	component side (top) solder mask
.sts	solder side (bottom) solder mask
.drd	excellon drill description
.drl	drill rack data
.dri	excellon drill tool description
.oln	board outline
.stt	component side (top) stencil
.stb	solder side (bottom) stencil
.gpi	general pcb information